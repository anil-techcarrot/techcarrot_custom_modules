# -*- coding: utf-8 -*-
from . import tec_employee
from . import tec_employee_relationship
from . import tec_employment_status
from . import tec_religion
from . import tec_language_master
from . import tec_exit_type
from . import tec_exit_reason
from . import tec_employee_practice
from . import tec_sub_practice
from . import tec_employee_category
from . import tec_contract
from . import tec_expense

