from . import hr_employee
from . import hr_department
from . import azure_license_config
from . import employee_code_auto_generate
from . import employee_code_wizard