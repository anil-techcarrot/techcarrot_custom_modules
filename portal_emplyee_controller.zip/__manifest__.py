{
    'name': 'Portal Employee Sync',
    'version': '1.0',
    'summary': 'Sync employees from portal to Odoo automatically',
    'description': 'Fetch employees from portal using API and create in Odoo HR Employee module',
    'author': 'Your Name',
    'category': 'Human Resources',
    'depends': ['base', 'hr'],
    'data': [
        'data/cron_job.xml',
        'security/ir.model.access.csv',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
