from odoo import http
from odoo.http import request

class PortalEmployeeController(http.Controller):

    @http.route('/api/employees', type='json', auth='none', methods=['GET'])
    def get_employees(self):
        # You can protect this with your API key
        api_key = request.httprequest.headers.get('API-Key')
        if api_key != 'b2013c472489ff77281ffb6875adf5f007782135':
            return {'error': 'Invalid API Key'}

        employees = request.env['hr.employee'].sudo().search([])
        data = []
        for emp in employees:
            data.append({
                'id': emp.id,
                'name': emp.name,
                'work_email': emp.work_email,
                'work_phone': emp.work_phone,
                'job_title': emp.job_id.name if emp.job_id else False,
                'department': emp.department_id.name if emp.department_id else False,
            })
        return data
