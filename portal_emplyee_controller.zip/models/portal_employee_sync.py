from odoo import models, api
import requests
import logging

_logger = logging.getLogger(__name__)

class PortalEmployeeSync(models.Model):
    _name = 'portal.employee.sync'
    _description = 'Portal Employee Sync'

    @api.model
    def cron_sync_portal_employees(self):
        url = 'http://your-portal-server/employees.json'
        headers = {'x-api-key': 'b2013c472489ff77281ffb6875adf5f007782135'}
        try:
            response = requests.get(url, headers=headers, timeout=10)
            if response.status_code == 200:
                employees = response.json()
                for emp in employees:
                    existing = self.env['hr.employee'].sudo().search([('work_email', '=', emp['email'])])
                    if not existing:
                        self.env['hr.employee'].sudo().create({
                            'name': f"{emp['firstName']} {emp['lastName']}",
                            'work_email': emp['email'],
                            'work_phone': emp.get('phone', False),
                            'job_id': self.env['hr.job'].sudo().search([('name', '=', emp.get('position'))], limit=1).id,
                            'department_id': self.env['hr.department'].sudo().search([('name', '=', emp.get('department'))], limit=1).id,
                        })
        except Exception as e:
            _logger.error("Portal Employee Sync Error: %s", e)
